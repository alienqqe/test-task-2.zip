export interface GlobalCustomField {
  id: string
  name: string
}
