/* eslint-disable no-console */
import { HostType } from '../types/HostType'
import { ProjectCustomField } from '../types/ProjectCustomField'

export const fetchFlagValue = async (
  projectId: string,
  host: HostType | null
) => {
  if (!host) {
    return null
  }

  try {
    const projectFields: ProjectCustomField[] = await host.fetchYouTrack(
      `admin/projects/${projectId}/customFields?fields=id,canBeEmpty,emptyFieldText,project(id,name),field(id,name),value(name)`,
      { method: 'GET' }
    )

    // find the flag field
    const flagField = projectFields.find((field) => field.field.name === 'Flag')

    if (!flagField) {
      return null
    }

    return flagField?.emptyFieldText === 'true' // convert to boolean
  } catch (error) {
    console.error(`Error fetching flag value for ${projectId}:`, error)
    return null
  }
}
