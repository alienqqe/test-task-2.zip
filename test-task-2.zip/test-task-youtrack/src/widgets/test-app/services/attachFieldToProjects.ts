/* eslint-disable no-console */
/* eslint-disable no-magic-numbers */
import { GlobalCustomField } from '../types/GlobalCustomField'
import { HostType } from '../types/HostType'
import { Project } from '../types/Project'
import { ProjectCustomField } from '../types/ProjectCustomField'
import { getCustomFields } from './getCustomFields'
import { getProjectCustomFields } from './getProjectCustomFields'

export const attachFieldToProjects = async (
  customField: GlobalCustomField,
  projectList: Project[],
  host: HostType | null
) => {
  if (!host) {
    return
  }

  await Promise.all(
    projectList.map(async (project) => {
      try {
        const projectFields = await getProjectCustomFields(project.id, host)
        // get the field
        const flagField = projectFields.find(
          (field: ProjectCustomField) => field.field.name === 'Flag'
        )

        if (flagField) {
          return
        }

        // send request to attach field to the project
        await host.fetchYouTrack(`admin/projects/${project.id}/customFields`, {
          method: 'POST',
          body: {
            field: {
              id: customField.id,
              name: 'Flag',
            },

            $type: 'SimpleProjectCustomField',
          },
          headers: { 'Content-Type': 'application/json' },
        })

        await new Promise((res) => setTimeout(res, 2000)) // Wait 2 sec
        await getCustomFields(host)
      } catch (e) {
        console.error(`Failed to attach custom field to ${project.id}:`, e)
      }
    })
  )
}
