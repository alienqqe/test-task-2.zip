/* eslint-disable no-magic-numbers */
/* eslint-disable no-console */

import { GlobalCustomField } from '../types/GlobalCustomField'
import { HostType } from '../types/HostType'
import { Project } from '../types/Project'
import { attachFieldToProjects } from './attachFieldToProjects'
import { getCustomFields } from './getCustomFields'

// function to create customField on the backend and attach it to the projects
export const createCustomField = async (
  projectList: Project[],
  host: HostType | null
) => {
  if (!host) {
    return
  }

  try {
    let listOfCustomFields = await getCustomFields(host)

    let customField = listOfCustomFields.find(
      (field: GlobalCustomField) => field.name === 'Flag'
    )

    if (!customField) {
      // create the field
      customField = await host.fetchYouTrack(
        `admin/customFieldSettings/customFields?fields=id,bundle(id,isUpdateable,name,values(archived,releaseDate,released,id,name)),canBeEmpty,emptyFieldText,field(name,aliases,id,isAutoAttached,isDisplayedInIssueList,isPublic,isUpdateable),project(id,name)`,
        {
          method: 'POST',
          body: {
            name: 'Flag',
            fieldType: {
              id: 'text',
            },
            emptyFieldText: 'false',
            isAutoAttached: false,
            isPublic: true,
          },
        }
      )
    }

    // ensure we get the latest list of fields
    await new Promise((res) => setTimeout(res, 2000)) // small delay for backend sync
    listOfCustomFields = await getCustomFields(host)
    customField = listOfCustomFields.find(
      (field: GlobalCustomField) => field.name === 'Flag'
    )

    if (!customField) {
      console.error('Failed to create custom field.')
      return
    }

    // attach custom field to every project
    await attachFieldToProjects(customField, projectList, host)
  } catch (error) {
    console.error('Error creating global custom field:', error)
  }
}
