/* eslint-disable no-magic-numbers */
/* eslint-disable no-console */
import { ProjectCustomField } from '../types/ProjectCustomField'
import { getProjectCustomFields } from './getProjectCustomFields'
import { HostType } from '../types/HostType'
import { Project } from '../types/Project'

export const updateFlag = async (
  host: HostType | null,
  projectId: string,
  newFlag: boolean,
  setFlagValues: React.Dispatch<React.SetStateAction<Project[]>>
) => {
  if (!host) {
    return
  }

  try {
    let flagField: ProjectCustomField | undefined
    let retries = 5

    while (retries > 0) {
      const projectFields = await getProjectCustomFields(projectId, host)
      flagField = projectFields.find((field) => field.field.name === 'Flag')
      if (flagField) {
        break
      }

      console.warn(`Flag field not found, retrying...`)
      retries--
      await new Promise((res) => setTimeout(res, 1000))
    }

    if (!flagField) {
      console.error('Flag field is not found after 5 retries')
      return
    }

    await host.fetchYouTrack(
      `admin/projects/${projectId}/customFields/${flagField.id}`,
      {
        method: 'POST',
        body: {
          emptyFieldText: `${newFlag.toString()}`,
        },
        headers: { 'Content-Type': 'application/json' },
      }
    )

    setFlagValues((prevFlags) =>
      prevFlags.map((p) => (p.id === projectId ? { ...p, flag: newFlag } : p))
    )
  } catch (e) {
    console.error(e)
  }
}
