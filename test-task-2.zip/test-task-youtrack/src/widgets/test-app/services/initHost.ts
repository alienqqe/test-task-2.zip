import { useHostStore } from '../zustand/store'

export async function initHost() {
  const host = await YTApp.register()
  useHostStore.getState().setHost(host)
}
