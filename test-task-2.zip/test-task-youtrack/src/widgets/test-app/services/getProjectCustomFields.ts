/* eslint-disable no-console */
import { HostType } from '../types/HostType'
import { ProjectCustomField } from '../types/ProjectCustomField'

export const getProjectCustomFields = async (
  projectId: string,
  host: HostType | null
) => {
  if (!host) {
    return []
  }

  try {
    // fetch customFields attached to project
    const projectFields: ProjectCustomField[] = await host.fetchYouTrack(
      `admin/projects/${projectId}/customFields?fields=id,canBeEmpty,emptyFieldText,project(id,name),field(id,name)`,
      {
        method: 'GET',
      }
    )

    return projectFields
  } catch (e) {
    console.error("Error while fetching project's custom fields", e)
    return []
  }
}
