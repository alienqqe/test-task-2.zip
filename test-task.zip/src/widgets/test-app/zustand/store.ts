import { create } from 'zustand'
import { HostType } from '../types/HostType'

type HostStore = {
  host: HostType | null
  setHost: (host: HostType) => void
}

export const useHostStore = create<HostStore>((set) => ({
  host: null,
  setHost: (host) => set({ host }),
}))
