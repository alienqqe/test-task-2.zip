import React, { memo, useEffect, useState } from 'react'
import Toggle from '@jetbrains/ring-ui-built/components/toggle/toggle'
import { Project } from './types/Project'
import { initHost } from './services/initHost'
import { useHostStore } from './zustand/store'
import { fetchProjects } from './services/fetchProjects'
import { createCustomField } from './services/createCustomField'
import { updateFlag } from './services/updateFlag'
import { fetchFlagValue } from './services/fetchFlagValue'

const AppComponent: React.FunctionComponent = () => {
  const host = useHostStore((state) => state.host)
  const [flagValues, setFlagValues] = useState<Project[]>([])
  const [projects, setProjects] = useState<Project[]>([])

  // init host
  useEffect(() => {
    const initializeHost = async () => {
      await initHost()
    }
    initializeHost()
  }, [])

  useEffect(() => {
    const initialize = async () => {
      if (!host) {
        return
      }

      let proj = await fetchProjects(host)
      setProjects(proj)

      if (proj.length > 0) {
        await createCustomField(proj, host)
        proj = await fetchProjects(host)
        setProjects(proj)
      }
    }
    initialize()
  }, [host])

  // fetch flags after projects are loaded
  useEffect(() => {
    const initializeFlags = async () => {
      if (!projects.length || !host) {
        return
      }

      const values = await Promise.all(
        projects.map(async (proj) => {
          const flag = await fetchFlagValue(proj.id, host)
          return {
            ...proj,
            flag: flag ?? false,
          }
        })
      )
      setFlagValues(values)
    }
    initializeFlags()
  }, [projects, host])

  // ensures the flag field exists on all projects and refreshes projects after creation
  useEffect(() => {
    const setupFieldAndRefresh = async () => {
      if (projects.length > 0) {
        await createCustomField(projects, host) // Ensure the field is created
        const res = await fetchProjects(host) // Refresh projects AFTER ensuring field exists
        setProjects(res)
      }
    }
    setupFieldAndRefresh()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [host])

  return (
    <div className='widget'>
      {projects.map((item, idx) => (
        <div key={item.id} className='projects-div'>
          {flagValues[idx] ? (
            <>
              <h1>{item.name}</h1>
              <h1>{`Flag is: ${flagValues[idx].flag}`}</h1>
              <Toggle
                key={item.id}
                checked={flagValues[idx].flag}
                onClick={() =>
                  updateFlag(
                    host,
                    flagValues[idx].id,
                    !flagValues[idx].flag,
                    setFlagValues
                  )
                }
              />
            </>
          ) : (
            <h1>Loading...</h1>
          )}
        </div>
      ))}
    </div>
  )
}

export const App = memo(AppComponent)
