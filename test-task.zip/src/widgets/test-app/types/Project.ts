export interface Project {
  id: string
  name: string
  flag: boolean
}
