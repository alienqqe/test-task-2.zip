export interface ProjectCustomField {
  field: {
    name: string
    id: string
  }
  id: string
  emptyFieldText: string
}
