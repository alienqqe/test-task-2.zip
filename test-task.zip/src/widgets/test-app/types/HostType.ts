import {
  EmbeddableWidgetAPI,
  PluginEndpointAPILayer,
} from '../../../../@types/globals'

export type HostType = PluginEndpointAPILayer | EmbeddableWidgetAPI
