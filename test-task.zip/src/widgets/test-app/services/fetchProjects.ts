import { HostType } from '../types/HostType'
import { Project } from '../types/Project'

export const fetchProjects = async (host: HostType | null) => {
  if (!host) {
    return []
  }

  const res: Project[] = await host.fetchYouTrack(
    `admin/projects?fields=id,name,type`,
    { method: 'GET' }
  )

  return res
}
