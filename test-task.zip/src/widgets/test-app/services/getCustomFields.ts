/* eslint-disable no-console */
import { GlobalCustomField } from '../types/GlobalCustomField'
import { HostType } from '../types/HostType'

export const getCustomFields = async (host: HostType | null) => {
  if (!host) {
    return []
  }

  try {
    // fetch the list of all customFields
    const listOfCustomFields: GlobalCustomField[] = await host.fetchYouTrack(
      'admin/customFieldSettings/customFields?fields=id,name,fieldType(presentation,id)',
      {
        method: 'GET',
      }
    )

    return listOfCustomFields
  } catch (e) {
    console.error(e)
    return []
  }
}
